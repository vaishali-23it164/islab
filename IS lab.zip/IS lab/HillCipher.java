import java.util.*;
public class HillCipher {
    static final int MOD = 26;
    public static int mulinv(int a, int b) {
        a = ((a % b) + b) % b;
        for (int x = 1; x < b; x++) {
            if ((a * x) % b == 1) return x;
        }
        return -1; 
    }
    public static int[][] matmul(int[][] a, int[][] b, int p, int q, int r, int s) {
        int[][] result = new int[p][s];
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < s; j++) {
                for (int k = 0; k < q; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
                result[i][j] %= MOD;
            }
        }
        return result;
    }
    public static int det2x2(int[][] a) {
        int det = (a[0][0] * a[1][1] - a[0][1] * a[1][0]) % MOD;
        return (det < 0) ? det + MOD : det;
    }
    public static int det3x3(int[][] a) {
        int det = a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
                - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
                + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
        det %= MOD;
        return (det < 0) ? det + MOD : det;
    }
    public static int[][] scalmul(int[][] a, int p, int q, int detKeyInv) {
        int[][] result = new int[p][q];
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                result[i][j] = ((a[i][j] * detKeyInv) % MOD + MOD) % MOD;
            }
        }
        return result;
    }
    public static int[][] strtomat(String PT, int k) {
        PT = PT.toUpperCase();
        while (PT.length() % k != 0) PT += "X";
        int rows = PT.length() / k;
        int[][] mat = new int[rows][k];
        int idx = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < k; j++) {
                mat[i][j] = PT.charAt(idx++) - 'A';
            }
        }
        return mat;
    }
    public static String mattostr(int[][] mat, int p, int q) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                sb.append((char) (mat[i][j] + 'A'));
            }
        }
        return sb.toString();
    }
    public static int[][] inverse2x2(int[][] key) {
        int det = det2x2(key);
        int detInv = mulinv(det, MOD);
        if (detInv == -1) return null;
        int[][] adj = {
            { key[1][1], -key[0][1] },
            { -key[1][0], key[0][0] }
        };
        return scalmul(adj, 2, 2, detInv);
    }
    public static int[][] inverse3x3(int[][] key) {
        int det = det3x3(key);
        int detInv = mulinv(det, MOD);
        if (detInv == -1) return null;
        int[][] adj = new int[3][3];
        adj[0][0] = (key[1][1] * key[2][2] - key[1][2] * key[2][1]);
        adj[0][1] = -(key[1][0] * key[2][2] - key[1][2] * key[2][0]);
        adj[0][2] = (key[1][0] * key[2][1] - key[1][1] * key[2][0]);
        adj[1][0] = -(key[0][1] * key[2][2] - key[0][2] * key[2][1]);
        adj[1][1] = (key[0][0] * key[2][2] - key[0][2] * key[2][0]);
        adj[1][2] = -(key[0][0] * key[2][1] - key[0][1] * key[2][0]);
        adj[2][0] = (key[0][1] * key[1][2] - key[0][2] * key[1][1]);
        adj[2][1] = -(key[0][0] * key[1][2] - key[0][2] * key[1][0]);
        adj[2][2] = (key[0][0] * key[1][1] - key[0][1] * key[1][0]);
        int[][] adjT = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                adjT[i][j] = ((adj[j][i] % MOD) + MOD) % MOD;
            }
        }
        return scalmul(adjT, 3, 3, detInv);
    }
    public static String encrypt(String plainText, int[][] key) {
        int size = key.length;
        int[][] ptMatrix = strtomat(plainText, size);
        int[][] ctMatrix = matmul(ptMatrix, key, ptMatrix.length, size, size, size);
        return mattostr(ctMatrix, ptMatrix.length, size);
    }
    public static String decrypt(String cipherText, int[][] key) {
        int size = key.length;
        int[][] keyInv = (size == 2) ? inverse2x2(key) : inverse3x3(key);
        if (keyInv == null) return "No inverse key!";
        int[][] ctMatrix = strtomat(cipherText, size);
        int[][] ptMatrix = matmul(ctMatrix, keyInv, ctMatrix.length, size, size, size);
        return mattostr(ptMatrix, ctMatrix.length, size);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter matrix size (2 or 3): ");
        int n = sc.nextInt();
        int[][] key = new int[n][n];
        System.out.println("Enter the key matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                key[i][j] = sc.nextInt() % MOD;
            }
        }
        sc.nextLine();
        System.out.print("Enter plaintext: ");
        String plain = sc.nextLine();
        String cipher = encrypt(plain, key);
        System.out.println("Ciphertext: " + cipher);
        String decrypted = decrypt(cipher, key);
        System.out.println("Decrypted: " + decrypted);
        sc.close();
    }
}
