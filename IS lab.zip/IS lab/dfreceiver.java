import java.io.*;
import java.net.*;
import java.util.*;
public class dfreceiver {
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost", 5000);
        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        Scanner sc = new Scanner(System.in);
        long p = dis.readLong();
        long g = dis.readLong();
        long A = dis.readLong();
        System.out.println("Received p = " + p + ", g = " + g + ", A = " + A);
        System.out.print("Enter private key b: ");
        long b = sc.nextLong();
        long B = mod(g, b, p);
        dos.writeLong(B);
        long key = mod(A, b, p);
        System.out.println("Shared Key (Receiver): " + key);
        s.close();
        sc.close();
    }
    static long mod(long base, long exp, long mod) {
        long result = 1;
        for (int i = 0; i < exp; i++)
            result = (result * base) % mod;
        return result;
    }
}
