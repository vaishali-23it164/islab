import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.Scanner;
public class dictionaryattack {
    private static final String WORD_FILE = "words.txt";
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            Path wordFilePath = Paths.get(WORD_FILE);
            if (!Files.exists(wordFilePath)) {
                System.out.println(WORD_FILE + " not found. Generating all 4-letter combinations...");
                generateAndStoreWords(wordFilePath);
                System.out.println("File generated successfully: " + WORD_FILE);
            } else {
                System.out.println("File found: " + WORD_FILE);
            }
            System.out.print("Enter password to check (e.g., 12ab): ");
            String input = sc.nextLine().trim();
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            String inputHash = sha256Hex(input,digest);
            boolean found = isPasswordHashPresent(wordFilePath, inputHash);
            if (found) {
                System.out.println("Password FOUND in file!");
            } else {
                System.out.println("Password NOT FOUND in file!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static void generateAndStoreWords(Path outFile) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(outFile)) {
            for (char d1 = '0'; d1 <= '9'; d1++) {
                for (char d2 = '0'; d2 <= '9'; d2++) {
                    for (char c1 = 'a'; c1 <= 'z'; c1++) {
                        for (char c2 = 'a'; c2 <= 'z'; c2++) {
                            writer.write("" + d1 + d2 + c1 + c2);
                            writer.newLine();
                        }
                    }
                }
            }
        }
    }
    private static boolean isPasswordHashPresent(Path file, String targetHash)
            throws IOException, NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String word;
            while ((word= reader.readLine()) != null) {
                if (sha256Hex(word, digest).equals(targetHash)) {
                    System.out.println(sha256Hex(word, digest) + " matches " + targetHash);
                    return true;
                }
            }
        }
        return false;
    }
    private static String sha256Hex(String input, MessageDigest digest) {
        digest.reset();
        byte[] hashed = digest.digest(input.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hashed) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    } 
}
