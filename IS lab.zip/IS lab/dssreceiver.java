import java.io.*;
import java.net.*;
import java.util.*;
public class dssreceiver {
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost", 5000);
        DataInputStream dis = new DataInputStream(s.getInputStream());
        long p = dis.readLong();
        long q = dis.readLong();
        long g = dis.readLong();
        long y = dis.readLong();
        long m = dis.readLong();
        long r = dis.readLong();
        long s_sig = dis.readLong();
        long w = modInverse(s_sig, q);
        long u1 = (m * w) % q;
        long u2 = (r * w) % q;
        long v = (modPow(g, u1, p) * modPow(y, u2, p)) % p % q;
        System.out.println("Received: m=" + m + ", r=" + r + ", s=" + s_sig);
        System.out.println("Verification v=" + v);
        if (v == r) System.out.println("Signature Verified");
        else System.out.println("Signature Invalid");
        s.close();
    }
    static long modPow(long b, long e, long m) {
        long r = 1;
        for (int i = 0; i < e; i++) r = (r * b) % m;
        return r;
    }
    static long modInverse(long a, long m) {
        a = a % m;
        for (long x = 1; x < m; x++)
            if ((a * x) % m == 1) return x;
        return -1;
    }
}
