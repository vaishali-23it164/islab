import java.io.*;
import java.net.*;
import java.util.*;
public class rsasender {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(5000);
        Socket s = ss.accept();
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        DataInputStream dis = new DataInputStream(s.getInputStream());
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first prime p: ");
        long p = sc.nextLong();
        System.out.print("Enter second prime q: ");
        long q = sc.nextLong();
        dos.writeLong(p);
        dos.writeLong(q);
        long n = p * q;
        long phi = (p - 1) * (q - 1);
        long e = 2;
        while (gcd(e, phi) != 1)
            e++;
        long d = modInverse(e, phi);
        System.out.println("Public key (e, n): (" + e + ", " + n + ")");
        System.out.println("Private key (d, n): (" + d + ", " + n + ")");
        dos.writeLong(e);
        dos.writeLong(n);
        System.out.print("Enter message (number): ");
        long msg = sc.nextLong();
        long encrypted = modPow(msg, e, n);
        System.out.println("Encrypted message: " + encrypted);
        dos.writeLong(encrypted);
        long decrypted = dis.readLong();
        System.out.println("Decrypted message (from receiver): " + decrypted);
        s.close();
        ss.close();
        sc.close();
    }
    static long gcd(long a, long b) {
        return b == 0 ? a : gcd(b, a % b);
    }
    static long modInverse(long e, long phi) {
        for (long d = 1; d < phi; d++)
            if ((e * d) % phi == 1)
                return d;
        return -1;
    }
    static long modPow(long base, long exp, long mod) {
        long result = 1;
        for (int i = 0; i < exp; i++)
            result = (result * base) % mod;
        return result;
    }
}
