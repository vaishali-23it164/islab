import java.util.*;
public class hckp {
    static final int MOD = 26;
    public static int mulinv(int a, int b) {
        a = ((a % b) + b) % b;
        for (int x = 1; x < b; x++) if ((a * x) % b == 1) return x;
        return -1;
    }
    public static int[][] matmul(int[][] a, int[][] b, int p, int q, int r, int s) {
        int[][] result = new int[p][s];
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < s; j++) {
                for (int k = 0; k < q; k++) result[i][j] += a[i][k] * b[k][j];
                result[i][j] = ((result[i][j] % MOD) + MOD) % MOD;
            }
        }
        return result;
    }
    public static int det2x2(int[][] a) {
        int det = (a[0][0] * a[1][1] - a[0][1] * a[1][0]) % MOD;
        return (det < 0) ? det + MOD : det;
    }
    public static int det3x3(int[][] a) {
        int det = a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
                - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
                + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]);
        det %= MOD;
        return (det < 0) ? det + MOD : det;
    }
    public static int[][] scalmul(int[][] a, int p, int q, int detKeyInv) {
        int[][] result = new int[p][q];
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                result[i][j] = ((a[i][j] * detKeyInv) % MOD + MOD) % MOD;
            }
        }
        return result;
    }
    public static int[][] inverse2x2(int[][] key) {
        int det = det2x2(key);
        int detInv = mulinv(det, MOD);
        if (detInv == -1) return null;
        int[][] adj = {
            { key[1][1], -key[0][1] },
            { -key[1][0], key[0][0] }
        };
        return scalmul(adj, 2, 2, detInv);
    }
    public static int[][] inverse3x3(int[][] key) {
        int det = det3x3(key);
        int detInv = mulinv(det, MOD);
        if (detInv == -1) return null;
        int[][] adj = new int[3][3];
        adj[0][0] = (key[1][1] * key[2][2] - key[1][2] * key[2][1]);
        adj[0][1] = -(key[1][0] * key[2][2] - key[1][2] * key[2][0]);
        adj[0][2] = (key[1][0] * key[2][1] - key[1][1] * key[2][0]);
        adj[1][0] = -(key[0][1] * key[2][2] - key[0][2] * key[2][1]);
        adj[1][1] = (key[0][0] * key[2][2] - key[0][2] * key[2][0]);
        adj[1][2] = -(key[0][0] * key[2][1] - key[0][1] * key[2][0]);
        adj[2][0] = (key[0][1] * key[1][2] - key[0][2] * key[1][1]);
        adj[2][1] = -(key[0][0] * key[1][2] - key[0][2] * key[1][0]);
        adj[2][2] = (key[0][0] * key[1][1] - key[0][1] * key[1][0]);
        int[][] adjT = new int[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                adjT[i][j] = ((adj[j][i] % MOD) + MOD) % MOD;

        return scalmul(adjT, 3, 3, detInv);
    }
    public static void printMatrix(int[][] mat) {
        for (int[] row : mat) {
            for (int val : row) System.out.print(val + " ");
            System.out.println();
        }
    }
    public static int[][] knownPlaintextAttack(String plain, String cipher, int n) {
        plain = plain.toUpperCase().replaceAll("[^A-Z]", "");
        cipher = cipher.toUpperCase().replaceAll("[^A-Z]", "");
        if (plain.length() < n * n || cipher.length() < n * n) {
            System.out.println("Need at least " + (n * n) + " chars of plaintext/ciphertext.");
            return null;
        }
        int[][] P = new int[n][n];
        int[][] C = new int[n][n];
        int idx = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                P[i][j] = plain.charAt(idx) - 'A';
                C[i][j] = cipher.charAt(idx) - 'A';
                idx++;
            }
        int[][] PInv = (n == 2) ? inverse2x2(P) : inverse3x3(P);
        if (PInv == null) {
            System.out.println("Plaintext matrix not invertible.");
            return null;
        }
        return matmul(C, PInv, n, n, n, n);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter matrix size (2 or 3): ");
        int n = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter known plaintext: ");
        String plain = sc.nextLine();
        System.out.print("Enter known ciphertext: ");
        String cipher = sc.nextLine();
        int[][] key = knownPlaintextAttack(plain, cipher, n);
        if (key != null) {
            System.out.println("Recovered key matrix:");
            printMatrix(key);
        }
    }
}