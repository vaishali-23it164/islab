import java.io.*;
import java.net.*;
import java.util.*;
public class dfsender {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(5000);
        Socket s = ss.accept();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter prime number p: ");
        long p = sc.nextLong();
        long g = findG(p);
        System.out.println("Calculated g = " + g);
        System.out.print("Enter private key a: ");
        long a = sc.nextLong();
        long A = mod(g, a, p);
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        DataInputStream dis = new DataInputStream(s.getInputStream());
        dos.writeLong(p);
        dos.writeLong(g);
        dos.writeLong(A);
        long B = dis.readLong();
        long key = mod(B, a, p);
        System.out.println("Shared Key (Sender): " + key);
        s.close();
        ss.close();
        sc.close();
    }
    static long mod(long base, long exp, long mod) {
        long result = 1;
        for (int i = 0; i < exp; i++)
            result = (result * base) % mod;
        return result;
    }
    static long findG(long p) {
        for (long g = 2; g < p; g++) {
            boolean flag = true;
            for (long i = 1; i < p - 1; i++) {
                if (mod(g, i, p) == 1) {
                    flag = false;
                    break;
                }
            }
            if (flag)
                return g;
        }
        return -1;
    }
}
