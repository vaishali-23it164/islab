import java.io.*;
import java.net.*;
import java.util.*;
public class dsssender {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(5000);
        Socket s = ss.accept();
        Scanner sc = new Scanner(System.in);
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        System.out.print("Enter prime p: ");
        long p = sc.nextLong();
        System.out.print("Enter prime q: ");
        long q = sc.nextLong();
        long g = findG(p);
        System.out.print("Enter private key x: ");
        long x = sc.nextLong();
        long y = modPow(g, x, p);
        dos.writeLong(p); dos.writeLong(q); dos.writeLong(g); dos.writeLong(y);
        System.out.print("Enter message: ");
        long m = sc.nextLong();
        System.out.print("Enter random k: ");
        long k = sc.nextLong();
        long r = modPow(g, k, p) % q;
        long k_inv = modInverse(k, q);
        long s_sig = (k_inv * (m + x * r)) % q;
        dos.writeLong(m); dos.writeLong(r); dos.writeLong(s_sig);
        s.close(); ss.close();
        sc.close();
    }
    static long modPow(long b, long e, long m) {
        long r = 1;
        for (int i = 0; i < e; i++) r = (r * b) % m;
        return r;
    }
    static long modInverse(long a, long m) {
        a = a % m;
        for (long x = 1; x < m; x++)
            if ((a * x) % m == 1) return x;
        return -1;
    }
    static long findG(long p) {
        for (long g = 2; g < p; g++) {
            boolean flag = true;
            for (long i = 1; i < p - 1; i++) {
                if (modPow(g, i, p) == 1) {
                    flag = false;
                    break;
                }
            }
            if (flag)
                return g;
        }
        return -1;
    }
}
