import java.io.*;
import java.net.*;
import java.util.*;
public class rsareceiver {
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost", 5000);
        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        Scanner sc = new Scanner(System.in);
        long e = dis.readLong();
        long n = dis.readLong();
        long p = dis.readLong();
        long q = dis.readLong();
        long phi = (p - 1) * (q - 1);
        long d = modInverse(e, phi);
        long encrypted = dis.readLong();
        System.out.println("Received encrypted message: " + encrypted);
        long decrypted = modPow(encrypted, d, n);
        System.out.println("Decrypted message: " + decrypted);
        dos.writeLong(decrypted);
        s.close();
        sc.close();
    }
    static long modInverse(long e, long phi) {
        for (long d = 1; d < phi; d++)
            if ((e * d) % phi == 1)
                return d;
        return -1;
    }
    static long modPow(long base, long exp, long mod) {
        long result = 1;
        for (int i = 0; i < exp; i++)
            result = (result * base) % mod;
        return result;
    }
}
