const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));
mongoose
  .connect("mongodb://localhost:27017/playlistDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.error("MongoDB Connection Error:", err));
const SongSchema = new mongoose.Schema({
  name: { type: String, required: true },
  isFavorite: { type: Boolean, default: false },
});
const Song = mongoose.model("Song", SongSchema);
app.get("/api/songs", async (req, res) => {
  const songs = await Song.find();
  res.json(songs);
});
app.post("/api/songs", async (req, res) => {
  const song = new Song({ name: req.body.name });
  await song.save();
  res.json(song);
});
app.put("/api/songs/:id", async (req, res) => {
  const song = await Song.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json(song);
});
app.delete("/api/songs/:id", async (req, res) => {
  await Song.findByIdAndDelete(req.params.id);
  res.json({ message: "Song deleted" });
});
const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
