from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
driver = webdriver.Chrome()
wait = WebDriverWait(driver, 10)
driver.get("http://localhost:3000")
time.sleep(2)
def add_song(name):
    driver.find_element(By.CSS_SELECTOR, "input[placeholder='Enter song name']").clear()
    driver.find_element(By.CSS_SELECTOR, "input[placeholder='Enter song name']").send_keys(name)
    driver.find_element(By.CSS_SELECTOR, "button.add").click()
    wait.until(lambda d: any(name in r.find_element(By.CSS_SELECTOR, "td:nth-child(2)").text 
                             for r in d.find_elements(By.CSS_SELECTOR, "table tr:not(:first-child)")))
    print(f"Added song: {name}")
def play_song(index=0):
    rows = driver.find_elements(By.CSS_SELECTOR, "table tr:not(:first-child)")
    rows[index].find_element(By.CSS_SELECTOR, "button.play").click()
    time.sleep(1)
    now_playing = driver.find_element(By.CSS_SELECTOR, ".now-playing").text
    print(f"Playing song: {now_playing}")
def next_song():
    driver.find_element(By.CSS_SELECTOR, ".next").click()
    time.sleep(1)
    now_playing = driver.find_element(By.CSS_SELECTOR, ".now-playing").text
    print(f"⏭️ Next song playing: {now_playing}")
def toggle_fav(index=0):
    rows = driver.find_elements(By.CSS_SELECTOR, "table tr:not(:first-child)")
    rows[index].find_element(By.CSS_SELECTOR, "button.fav").click()
    time.sleep(0.5)
    fav_text = rows[index].find_element(By.CSS_SELECTOR, "td:nth-child(3)").text
    print(f"Favorite toggled: {fav_text}")
def edit_song(index=0, new_name=""):
    rows = driver.find_elements(By.CSS_SELECTOR, "table tr:not(:first-child)")
    edit_btn = rows[index].find_element(By.CSS_SELECTOR, "button.update")
    edit_btn.click()
    input_field = rows[index].find_element(By.CSS_SELECTOR, "td:nth-child(2) input")
    input_field.clear()
    input_field.send_keys(new_name)
    edit_btn.click()
    wait.until(lambda d: any(new_name in r.find_element(By.CSS_SELECTOR, "td:nth-child(2)").text 
                             for r in d.find_elements(By.CSS_SELECTOR, "table tr:not(:first-child)")))
    print(f"Edited song to: {new_name}")
def delete_song_by_name(name):
    while True:
        rows = driver.find_elements(By.CSS_SELECTOR, "table tr:not(:first-child)")
        found = False
        for r in rows:
            try:
                song_name = r.find_element(By.CSS_SELECTOR, "td:nth-child(2)").text
                if song_name == name:
                    r.find_element(By.CSS_SELECTOR, "button.delete").click()
                    found = True
                    time.sleep(0.5)  
                    break
            except:
                continue
        if not found:
            break
    print(f"Deleted all songs named: {name}")
add_song("Song 1")
add_song("Song 2")
play_song(0)
next_song()
toggle_fav(0)
toggle_fav(1)
edit_song(0, "Updated Song 1")
delete_song_by_name("Updated Song 1")
delete_song_by_name("Song 2")
print("Test completed and browser closed")
driver.quit()
