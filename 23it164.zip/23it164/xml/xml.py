from lxml import etree
xml = etree.parse("books.xml")
xslt = etree.parse("books.xsl")
transform = etree.XSLT(xslt)
result = transform(xml)
result.write("books.html", pretty_print=True)
print("Transformation complete. Check output.html")
